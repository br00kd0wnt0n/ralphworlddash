# Ralph.World Living Page

A single-view, no-scroll (desktop) living page for Ralph.World that aggregates projects, insights, trends, and original content into a vibrant, always-current destination.

## Quick Start

```bash
npm install
npm run dev
```

## Project Structure

```
src/
├── App.jsx                    # Main layout + responsive grid (desktop/tablet/mobile)
├── main.jsx                   # Entry point
├── index.css                  # Global styles + animations
├── data/
│   ├── theme.js               # Design tokens (colors, breakpoints)
│   └── content.js             # All content data (replace with CMS/API later)
├── hooks/
│   └── useBreakpoint.js       # Responsive breakpoint hook
└── components/
    ├── Glass.jsx              # Frosted glass card wrapper
    ├── Label.jsx              # Module header label
    ├── Overlay.jsx            # Detail overlay (blurred background)
    ├── Ticker.jsx             # Scrolling news ticker
    ├── VideoPlayer.jsx        # Ralph.TV video player
    ├── DailyRead.jsx          # Magazine quote rotator (hero module)
    ├── ListenButton.jsx       # "Listen to Ralph.World" AI podcast
    ├── LatestLaunches.jsx     # Project showcase grid
    ├── InnovationLab.jsx      # FREQUENCY prototype feature
    ├── IndustryPulse.jsx      # Industry market data
    ├── TrendingRotator.jsx    # Rotating platform trends (Apify)
    ├── FromArchive.jsx        # Random past project/mag feature
    └── SignalFooter.jsx       # Global office status footer
```

## Integration Points

### 1. WebGL Canvas Background

In `src/App.jsx`, set `CANVAS_URL` to your Ralph canvas iframe URL:

```js
const CANVAS_URL = 'https://your-ralph-canvas.vercel.app';
```

The iframe is set to `pointerEvents: 'none'` so it won't intercept clicks on the glassmorphic modules floating above it. The fallback gradient will be used when `CANVAS_URL` is null.

### 2. Listen Feature (AI Podcast Digest)

Architecture for the "Listen to Ralph.World" feature:

1. Scrape current page content state
2. Send to Claude/GPT with a conversational script prompt
3. Pipe script to ElevenLabs with two distinct voice profiles
4. Cache audio with a TTL tied to content refresh cycle
5. Serve via audio element in ListenButton component

### 3. Trend Data (Apify)

Replace static `TRENDING` array in `content.js` with Apify API calls. Suggested scrape targets:
- TikTok trending hashtags/sounds
- Pinterest trending searches
- Instagram Reels engagement data
- YouTube Shorts trending topics
- X/Twitter discourse topics

### 4. Magazine Content (PDF Chatbot)

Replace static `MAG_QUOTES` with your existing mag chatbot API to pull daily quotes, articles, and insights from the PDF repository.

### 5. Video Content

Wire `VideoPlayer.jsx` to your video hosting (Mux, Cloudflare Stream, or direct embed). Currently a placeholder with waveform animation.

## Responsive Behavior

| Breakpoint | Layout | Scroll |
|-----------|--------|--------|
| Desktop (1024+) | 4-column grid, 3 rows | No scroll, all above fold |
| Tablet (768-1023) | 2-column grid | Vertical scroll |
| Mobile (<768) | Single column stack | Vertical scroll, no ticker |

## Claude Code Prompts

Use these to continue building in Claude Code:

**Wire up Apify trends:**
> Connect the TrendingRotator component to Apify API endpoints. Create a server-side route that fetches trending data from TikTok, Pinterest, Instagram, YouTube, and X scrapers. Cache results for 1 hour. Update content.js to pull from this endpoint instead of static data.

**Build the Listen feature:**
> Implement the AI podcast generation pipeline in ListenButton. On click: gather current page content from all modules, send to Claude API with a 2-host conversational script prompt, pipe the script to ElevenLabs with two voice profiles, return audio URL, play in-browser. Cache generated audio for 24 hours.

**Add video embed:**
> Replace the VideoPlayer placeholder with an actual video embed. Support Mux or Cloudflare Stream. Auto-play muted on desktop, tap-to-play on mobile. Show thumbnail/poster frame when paused.

**Connect magazine chatbot:**
> Wire DailyRead to the existing Ralph magazine PDF chatbot API. Pull a fresh quote/insight daily. Add a "Read more" action in the overlay that opens the full article.

## Deployment

```bash
npm run build    # outputs to dist/
```

Deploy `dist/` to Vercel, Netlify, or Railway.
