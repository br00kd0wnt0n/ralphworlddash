import { theme as R } from '../data/theme';
import { TICKER_ITEMS } from '../data/content';

export default function Ticker() {
  const doubled = [...TICKER_ITEMS, ...TICKER_ITEMS];
  return (
    <div
      style={{
        overflow: 'hidden',
        whiteSpace: 'nowrap',
        height: '34px',
        display: 'flex',
        alignItems: 'center',
        background: 'rgba(255,255,255,0.35)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid rgba(255,255,255,0.4)',
        flexShrink: 0,
      }}
    >
      <div style={{ display: 'inline-flex', gap: '48px', paddingLeft: '100%', animation: 'ticker 50s linear infinite' }}>
        {doubled.map((item, i) => (
          <span key={i} style={{ fontSize: '12px', fontFamily: "'DM Sans', sans-serif", fontWeight: 500, color: R.text, opacity: 0.65 }}>
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}
