import { useState } from 'react';
import { theme as R } from '../data/theme';

export default function Glass({ children, style, onClick }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? R.cardHover : R.card,
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        border: `1px solid ${R.cardBorder}`,
        borderRadius: '20px',
        transition: 'all 0.35s cubic-bezier(0.34, 1.56, 0.64, 1)',
        transform: hovered ? 'translateY(-3px) scale(1.005)' : 'translateY(0) scale(1)',
        boxShadow: hovered
          ? '0 20px 40px rgba(0,0,0,0.08), 0 4px 12px rgba(0,0,0,0.04)'
          : '0 8px 24px rgba(0,0,0,0.04), 0 2px 8px rgba(0,0,0,0.02)',
        overflow: 'hidden',
        cursor: onClick ? 'pointer' : 'default',
        ...style,
      }}
    >
      {children}
    </div>
  );
}
