import { useState, useEffect } from 'react';
import { theme as R } from '../data/theme';
import { OFFICES } from '../data/content';

export default function SignalFooter() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(iv);
  }, []);

  return (
    <div
      style={{
        height: '36px',
        flexShrink: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '28px',
        background: 'rgba(255,255,255,0.35)',
        backdropFilter: 'blur(12px)',
        borderTop: '1px solid rgba(255,255,255,0.4)',
        flexWrap: 'wrap',
        padding: '0 16px',
      }}
    >
      {OFFICES.map((o, i) => {
        const hour = parseInt(
          new Intl.DateTimeFormat('en-US', { hour: 'numeric', hour12: false, timeZone: o.tz }).format(now)
        );
        const isActive = hour >= 9 && hour < 18;
        const time = new Intl.DateTimeFormat('en-US', { hour: '2-digit', minute: '2-digit', hour12: true, timeZone: o.tz }).format(now);

        return (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ fontSize: '12px' }}>{o.emoji}</span>
            <span style={{ fontSize: '11px', fontWeight: 600, color: R.text, fontFamily: "'DM Sans', sans-serif" }}>{o.city}</span>
            <div
              style={{
                width: '6px',
                height: '6px',
                borderRadius: '50%',
                background: isActive ? R.green : 'rgba(26,26,46,0.15)',
                boxShadow: isActive ? `0 0 6px ${R.green}` : 'none',
                animation: isActive ? 'pulse 2s ease-in-out infinite' : 'none',
              }}
            />
            <span style={{ fontSize: '10px', color: R.textMuted, fontFamily: "'DM Mono', monospace" }}>{time}</span>
          </div>
        );
      })}
    </div>
  );
}
