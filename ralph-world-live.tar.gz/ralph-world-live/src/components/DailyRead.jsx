import { useState, useEffect } from 'react';
import { theme as R } from '../data/theme';
import { MAG_QUOTES } from '../data/content';
import Glass from './Glass';
import Label from './Label';

const themeColors = { attention: R.red, philosophy: R.orange, engagement: R.blue, culture: R.purple };

export default function DailyRead() {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const iv = setInterval(() => setIdx((i) => (i + 1) % MAG_QUOTES.length), 12000);
    return () => clearInterval(iv);
  }, []);

  const q = MAG_QUOTES[idx];
  const color = themeColors[q.theme];

  return (
    <Glass style={{ height: '100%', display: 'flex', flexDirection: 'column', background: `linear-gradient(135deg, rgba(255,255,255,0.6) 0%, ${color}08 100%)` }}>
      <div style={{ padding: '16px 22px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Label color={color}>📖 Daily Read</Label>
        <div
          style={{
            fontSize: '9px',
            fontWeight: 700,
            padding: '3px 10px',
            borderRadius: '20px',
            background: `${color}12`,
            color: color,
            fontFamily: "'DM Mono', monospace",
            textTransform: 'uppercase',
            letterSpacing: '0.5px',
          }}
        >
          {q.theme}
        </div>
      </div>
      <div style={{ flex: 1, padding: '0 22px 16px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
        <div style={{ fontSize: '48px', color: color, opacity: 0.2, lineHeight: 0.6, marginBottom: '8px', fontFamily: 'Georgia, serif', fontWeight: 700 }}>"</div>
        <div style={{ fontSize: '19px', color: R.text, lineHeight: 1.5, fontWeight: 500, fontFamily: 'Georgia, serif', marginBottom: '12px', letterSpacing: '-0.2px' }}>
          {q.text}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontSize: '11px', color: R.textLight, fontFamily: "'DM Mono', monospace" }}>{q.src}</div>
          <div style={{ display: 'flex', gap: '5px' }}>
            {MAG_QUOTES.map((_, i) => (
              <div
                key={i}
                onClick={() => setIdx(i)}
                style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  cursor: 'pointer',
                  background: i === idx ? color : 'rgba(26,26,46,0.1)',
                  transition: 'all 0.3s ease',
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </Glass>
  );
}
