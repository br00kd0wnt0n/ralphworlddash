import { useState, useEffect } from 'react';
import { theme as R } from '../data/theme';
import { TRENDING } from '../data/content';
import Glass from './Glass';
import Label from './Label';

export default function TrendingRotator() {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const iv = setInterval(() => setIdx((i) => (i + 1) % TRENDING.length), 5000);
    return () => clearInterval(iv);
  }, []);

  const t = TRENDING[idx];

  return (
    <Glass style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '14px 18px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Label color={R.orange}>🔥 Trending</Label>
        <div style={{ display: 'flex', gap: '4px' }}>
          {TRENDING.map((_, i) => (
            <div
              key={i}
              onClick={() => setIdx(i)}
              style={{
                width: '6px',
                height: '6px',
                borderRadius: '50%',
                cursor: 'pointer',
                background: i === idx ? R.orange : 'rgba(26,26,46,0.1)',
                transition: 'all 0.3s ease',
              }}
            />
          ))}
        </div>
      </div>
      <div style={{ flex: 1, padding: '0 18px 14px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
          <span style={{ fontSize: '16px' }}>{t.icon}</span>
          <span style={{ fontSize: '12px', fontWeight: 700, color: R.text, fontFamily: "'DM Sans', sans-serif" }}>{t.platform}</span>
          <span
            style={{
              fontSize: '10px',
              fontWeight: 700,
              color: R.green,
              fontFamily: "'DM Mono', monospace",
              padding: '1px 6px',
              borderRadius: '8px',
              background: `${R.green}10`,
            }}
          >
            {t.metric}
          </span>
        </div>
        <div style={{ fontSize: '15px', fontWeight: 800, color: R.text, fontFamily: "'DM Sans', sans-serif", lineHeight: 1.25, marginBottom: '6px' }}>{t.topic}</div>
        <div style={{ fontSize: '11px', color: R.textLight, lineHeight: 1.5, fontFamily: "'DM Sans', sans-serif" }}>{t.detail}</div>
        <div style={{ fontSize: '8px', color: R.textMuted, fontFamily: "'DM Mono', monospace", marginTop: '8px' }}>via Apify</div>
      </div>
    </Glass>
  );
}
