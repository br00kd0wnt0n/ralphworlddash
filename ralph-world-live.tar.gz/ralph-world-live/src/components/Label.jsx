import { theme as R } from '../data/theme';

export default function Label({ children, color }) {
  return (
    <div
      style={{
        fontSize: '10px',
        fontWeight: 700,
        letterSpacing: '1.5px',
        textTransform: 'uppercase',
        color: color || R.textLight,
        fontFamily: "'DM Mono', monospace",
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
      }}
    >
      {children}
    </div>
  );
}
