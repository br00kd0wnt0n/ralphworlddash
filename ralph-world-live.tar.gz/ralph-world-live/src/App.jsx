import { useState, useEffect } from 'react';
import { theme as R } from './data/theme';
import { useBreakpoint } from './hooks/useBreakpoint';

import Ticker from './components/Ticker';
import VideoPlayer from './components/VideoPlayer';
import LatestLaunches from './components/LatestLaunches';
import DailyRead from './components/DailyRead';
import ListenButton from './components/ListenButton';
import IndustryPulse from './components/IndustryPulse';
import InnovationLab from './components/InnovationLab';
import TrendingRotator from './components/TrendingRotator';
import FromArchive from './components/FromArchive';
import SignalFooter from './components/SignalFooter';
import Overlay from './components/Overlay';

// ─── CANVAS BACKGROUND ───
// TODO: Replace CANVAS_URL with your WebGL canvas URL
const CANVAS_URL = null; // e.g. 'https://your-ralph-canvas.vercel.app'

function CanvasBackground() {
  return (
    <>
      {CANVAS_URL ? (
        <iframe
          src={CANVAS_URL}
          title="Ralph Canvas"
          style={{
            position: 'fixed',
            inset: 0,
            width: '100%',
            height: '100%',
            border: 'none',
            zIndex: 0,
            pointerEvents: 'none',
          }}
        />
      ) : (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 0,
            background: `
              radial-gradient(ellipse at 15% 25%, ${R.pink}16 0%, transparent 45%),
              radial-gradient(ellipse at 85% 75%, ${R.blue}12 0%, transparent 45%),
              radial-gradient(ellipse at 50% 50%, ${R.yellow}10 0%, transparent 55%),
              radial-gradient(ellipse at 80% 20%, ${R.cyan}08 0%, transparent 40%),
              ${R.bg}
            `,
            animation: 'bgShift 25s ease-in-out infinite alternate',
          }}
        />
      )}
    </>
  );
}

// ─── HEADER ───
function Header({ isMobile }) {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const iv = setInterval(() => setTime(new Date()), 60000);
    return () => clearInterval(iv);
  }, []);

  return (
    <div
      style={{
        height: isMobile ? '44px' : '50px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: isMobile ? 'center' : 'space-between',
        padding: '0 24px',
        flexShrink: 0,
        background: 'rgba(255,255,255,0.35)',
        backdropFilter: 'blur(16px)',
        borderBottom: '1px solid rgba(255,255,255,0.4)',
        gap: '14px',
      }}
    >
      <div
        style={{
          padding: '3px 10px',
          borderRadius: '20px',
          fontSize: '9px',
          fontWeight: 700,
          background: `${R.red}12`,
          color: R.red,
          fontFamily: "'DM Mono', monospace",
          letterSpacing: '1px',
          display: 'flex',
          alignItems: 'center',
          gap: '5px',
        }}
      >
        <div style={{ width: '5px', height: '5px', borderRadius: '50%', background: R.red, animation: 'pulse 2s ease-in-out infinite' }} />
        LIVE
      </div>
      {!isMobile && (
        <div style={{ fontSize: '11px', color: R.textMuted, fontFamily: "'DM Mono', monospace" }}>
          {time.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })}
        </div>
      )}
    </div>
  );
}

// ─── DESKTOP GRID ───
function DesktopGrid({ onSelect }) {
  return (
    <div
      style={{
        flex: 1,
        padding: '12px 16px',
        minHeight: 0,
        display: 'grid',
        gridTemplateColumns: '1.8fr 1.3fr 1fr 1fr',
        gridTemplateRows: '1.1fr 0.9fr 1fr',
        gap: '10px',
      }}
    >
      <div style={{ gridRow: '1', gridColumn: '1 / 3' }}><DailyRead /></div>
      <div style={{ gridRow: '1', gridColumn: '3' }}><ListenButton /></div>
      <div style={{ gridRow: '1', gridColumn: '4' }}><IndustryPulse /></div>
      <div style={{ gridRow: '2 / 4', gridColumn: '1' }}><VideoPlayer /></div>
      <div style={{ gridRow: '2 / 4', gridColumn: '2' }}><LatestLaunches onSelect={onSelect} /></div>
      <div style={{ gridRow: '2', gridColumn: '3 / 5' }}><InnovationLab /></div>
      <div style={{ gridRow: '3', gridColumn: '3' }}><FromArchive onSelect={onSelect} /></div>
      <div style={{ gridRow: '3', gridColumn: '4' }}><TrendingRotator /></div>
    </div>
  );
}

// ─── TABLET GRID ───
function TabletGrid({ onSelect }) {
  return (
    <div
      style={{
        flex: 1,
        padding: '10px 12px',
        minHeight: 0,
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gridTemplateRows: 'auto auto auto auto auto',
        gap: '8px',
      }}
    >
      <div style={{ gridColumn: '1 / 3' }}><DailyRead /></div>
      <div style={{ minHeight: '220px' }}><VideoPlayer /></div>
      <div style={{ minHeight: '220px' }}><ListenButton /></div>
      <div style={{ gridColumn: '1 / 3', minHeight: '200px' }}><LatestLaunches onSelect={onSelect} /></div>
      <div style={{ gridColumn: '1 / 3', minHeight: '160px' }}><InnovationLab /></div>
      <div style={{ minHeight: '180px' }}><IndustryPulse /></div>
      <div style={{ minHeight: '180px' }}><TrendingRotator /></div>
      <div style={{ minHeight: '180px' }}><FromArchive onSelect={onSelect} /></div>
    </div>
  );
}

// ─── MOBILE STACK ───
function MobileStack({ onSelect }) {
  const moduleStyle = { minHeight: '200px' };
  return (
    <div style={{ padding: '10px 12px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
      <div style={moduleStyle}><DailyRead /></div>
      <div style={moduleStyle}><VideoPlayer /></div>
      <div style={moduleStyle}><ListenButton /></div>
      <div style={{ minHeight: '320px' }}><LatestLaunches onSelect={onSelect} /></div>
      <div style={{ minHeight: '180px' }}><InnovationLab /></div>
      <div style={{ minHeight: '200px' }}><IndustryPulse /></div>
      <div style={{ minHeight: '200px' }}><TrendingRotator /></div>
      <div style={moduleStyle}><FromArchive onSelect={onSelect} /></div>
    </div>
  );
}

// ─── APP ───
export default function App() {
  const { isMobile, isTablet, isDesktop } = useBreakpoint();
  const [overlayItem, setOverlayItem] = useState(null);

  return (
    <div
      style={{
        width: '100%',
        minHeight: '100vh',
        overflow: isDesktop ? 'hidden' : 'auto',
        position: 'relative',
        fontFamily: "'DM Sans', sans-serif",
      }}
    >
      <CanvasBackground />

      <div
        style={{
          position: 'relative',
          zIndex: 1,
          width: '100%',
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          ...(isDesktop ? { height: '100vh' } : {}),
        }}
      >
        <Header isMobile={isMobile} />
        {!isMobile && <Ticker />}

        {isDesktop && <DesktopGrid onSelect={setOverlayItem} />}
        {isTablet && <TabletGrid onSelect={setOverlayItem} />}
        {isMobile && <MobileStack onSelect={setOverlayItem} />}

        <SignalFooter />
      </div>

      <Overlay item={overlayItem} onClose={() => setOverlayItem(null)} />
    </div>
  );
}
