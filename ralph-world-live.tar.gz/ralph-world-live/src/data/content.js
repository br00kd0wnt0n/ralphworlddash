// ─── CONTENT DATA ───
// All content is centralized here for easy updates.
// TODO: Replace with CMS/API feeds when ready.

import { theme as R } from './theme';

export const TICKER_ITEMS = [
  '🧸 Care Bears dashboard: 12.4k views this week',
  '📈 TikTok trending: nostalgic IP reboots +340%',
  '🗼 Ralph Tokyo shipped: new social toolkit',
  '📌 Pinterest: dopamine decor searches +89% MoM',
  '🎬 Netflix Aerials: 2.1M impressions first 48hrs',
  '🎵 Ralph Radio: pilot episode drops Friday',
  '🌸 Disney Darlings EMEA: campaign live',
  '⚡ YouTube Shorts: tutorial-core aesthetic emerging',
  '📻 FREQUENCY prototype: Episode 1 playable',
  '🎤 SlopBowl: Super Bowl Sunday launch',
];

export const LAUNCHES = [
  {
    name: 'SlopBowl',
    client: 'Ralph Original',
    color: R.orange,
    date: 'Feb 2026',
    emoji: '🎤',
    tag: 'AI App',
    description:
      'Real-time AI roast machine for Super Bowl ads. Point your phone at any Big Game ad and get instant, unsolicited commentary from a jaded ad connoisseur who\'s seen every trick but still respects the craft.',
    link: 'slopbowl.ralph.world',
  },
  {
    name: 'Netflix Interactive Aerials',
    client: 'Netflix',
    color: R.red,
    date: 'Jan 2026',
    emoji: '✈️',
    tag: 'Interactive',
    description:
      'An interactive aerial experience built for Netflix that transforms passive viewing into participatory content, reaching 2.1M impressions in the first 48 hours.',
    link: null,
  },
  {
    name: 'Care Bears Social Hub',
    client: 'Cloudco',
    color: R.pink,
    date: 'Dec 2025',
    emoji: '🧸',
    tag: 'Dashboard',
    description:
      'Growth forecasting dashboard and social content hub for the Care Bears franchise. Data-driven content strategy that helped win a $500k engagement.',
    link: null,
  },
  {
    name: 'Disney Darlings EMEA',
    client: 'Disney',
    color: R.purple,
    date: 'Live Now',
    emoji: '👑',
    tag: 'Campaign',
    description:
      'Full EMEA launch campaign for Disney Darlings, spanning social content creation, influencer strategy, and cross-platform distribution across European markets.',
    link: null,
  },
  {
    name: 'Ralph Voices',
    client: 'Ralph Lab',
    color: R.cyan,
    date: 'Beta',
    emoji: '🎙️',
    tag: 'Product',
    description:
      'Synthetic audience testing platform using AI-generated voice profiles to simulate focus group reactions and audience sentiment before content goes live.',
    link: null,
  },
  {
    name: 'Narrativ Platform',
    client: 'Ralph Lab',
    color: R.blue,
    date: 'Beta',
    emoji: '📖',
    tag: 'Product',
    description:
      'Storytelling intelligence platform that surfaces narrative patterns across social data, helping brands find the stories their audiences actually want to hear.',
    link: null,
  },
];

export const TRENDING = [
  {
    platform: 'TikTok',
    icon: '▶',
    color: '#000',
    metric: '+340%',
    topic: 'Nostalgic IP reboots',
    detail:
      'Childhood brands remixed with irony. Care Bears, Polly Pocket, Tamagotchi content surging across creator accounts.',
  },
  {
    platform: 'Pinterest',
    icon: '📌',
    color: '#E60023',
    metric: '+89%',
    topic: 'Dopamine decor',
    detail:
      'Maximalist interiors, bold color blocking, playful object design. Anti-minimalism is the new aspiration.',
  },
  {
    platform: 'Instagram',
    icon: '📷',
    color: '#C13584',
    metric: '+215%',
    topic: 'Branded ASMR',
    detail:
      'Product-focused sensory content outperforming traditional branded reels by 3x on average engagement.',
  },
  {
    platform: 'YouTube',
    icon: '🎬',
    color: '#FF0000',
    metric: '+127%',
    topic: 'Tutorial-core',
    detail:
      "How-to content dressed in editorial aesthetics. The 'cool teacher' format is dominating Shorts.",
  },
  {
    platform: 'X',
    icon: '𝕏',
    color: '#000',
    metric: '+180%',
    topic: 'Comfort discourse',
    detail:
      "Audiences debating 'comfort content' vs 'challenge content'. Nostalgia fatigue emerging as counter-trend.",
  },
];

export const MAG_QUOTES = [
  {
    text: "The algorithm doesn't care about your brand deck. It cares about the first 0.3 seconds.",
    src: 'Ralph Magazine, Issue 7',
    theme: 'attention',
  },
  {
    text: 'Joy is not a strategy. Joy is the strategy.',
    src: 'Chris Hassell, Founder',
    theme: 'philosophy',
  },
  {
    text: 'Every scroll is a vote. What are you running for?',
    src: 'Ralph Magazine, Issue 12',
    theme: 'engagement',
  },
  {
    text: "The best content doesn't interrupt culture. It becomes culture.",
    src: 'Ralph Magazine, Issue 9',
    theme: 'culture',
  },
];

export const ARCHIVE = [
  {
    title: 'Behind the Aerials',
    type: 'Case Study',
    color: R.red,
    emoji: '✈️',
    year: '2025',
    description:
      'How we turned passive Netflix viewing into participatory content that reached millions in 48 hours.',
  },
  {
    title: 'Tokyo Night Market',
    type: 'Photo Essay',
    color: R.cyan,
    emoji: '🏮',
    year: '2024',
    description:
      "A visual exploration of Tokyo's underground creative scene through the lens of Ralph's Tokyo studio.",
  },
  {
    title: 'The Joy Issue',
    type: 'Magazine',
    color: R.yellow,
    emoji: '😊',
    year: '2024',
    description:
      'Our most popular print issue, exploring why joy is the most undervalued currency in advertising.',
  },
  {
    title: 'Creator Roundtable',
    type: 'Video',
    color: R.purple,
    emoji: '🎙️',
    year: '2025',
    description:
      'Six creators, one table, zero scripts. A candid conversation about the state of content creation.',
  },
];

export const INDUSTRY_DATA = [
  { label: 'Short-form video', value: '$12.4B', change: '+34%', color: R.red },
  { label: 'Creator economy', value: '$250B', change: '+22%', color: R.purple },
  { label: 'Social commerce', value: '$1.2T', change: '+18%', color: R.green },
];

export const OFFICES = [
  { city: 'New York', tz: 'America/New_York', emoji: '🗽' },
  { city: 'London', tz: 'Europe/London', emoji: '🎡' },
  { city: 'LA', tz: 'America/Los_Angeles', emoji: '🌴' },
  { city: 'Tokyo', tz: 'Asia/Tokyo', emoji: '⛩️' },
];
